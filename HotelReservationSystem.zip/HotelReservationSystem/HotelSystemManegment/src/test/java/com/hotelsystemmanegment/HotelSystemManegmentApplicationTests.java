package com.hotelsystemmanegment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelSystemManegmentApplicationTests {

    @Test
    void contextLoads() {
    }

}
