package com.hotelsystemmanegment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelSystemManegmentApplication {

    public static void main(String[] args) {
        SpringApplication.run(HotelSystemManegmentApplication.class, args);
    }

}
