package com.hotelsystemmanegment.Repositories;

public interface BookingRepository {
}
