package com.hotelsystemmanegment.Exception;

public class OurException extends RuntimeException{

    public OurException(String message){
        super(message);
    }
}
